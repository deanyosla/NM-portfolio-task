<div id="about" class="about-me container">
          <div class="tab-1">
            <h2>About</h2>
            <p>
              I am a creative person, throughout my life I have been intrigued
              by and interested in various art subjects.<br />
              Though personally I lean towards visual arts, be it painting,
              drawing or even digital design.<br />
              It always draws me in, even now it's one of my longest running
              hobbies which I can't see myself abandoning ever.
            </p>
          </div>
          <div class="tab-2">
            <h2>Interests</h2>
            <p>
              When it's a possibility I love to travel, and have visited some
              wonderful places across the Europe for now.<br />
              Haven't been further than that yet, although I do hope to be able
              to travel further eventually.<br />
              It's always exciting to experience cultures different to ours or
              even socialise with people I've not met before on those travels.
            </p>
          </div>
          <div class="tab-3">
            <h2>Coding Experience</h2>
            <p>
              Prior to joining Netmatters Scion Scheme course I can't say that I
              had known a whole lot about coding.<br />
              Other than that it exists and I have tried to self-educate myself
              in some form of Web Development before, albeit not very
              successfully.<br />
              For the short time that I've been part of this course I have
              managed to learn more than I thought I was capable of.<br />
              And I'm looking forward to learn even more as I progress through
              the course.
            </p>
          </div>
 </div>