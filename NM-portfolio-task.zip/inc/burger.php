<button class="hamburger" type="button">
        <span class="hamburger-box">
          <span class="hamburger-inner"></span>
        </span>
      </button>
      <div class="mobile-nav">
        <a class="index" href="index.php"><h1>AV</h1></a>
        <a href="about-me.php#about">
          <i class="fa-solid fa-address-card"></i>
          About Me
        </a>

        <a href="index.php#portfolio">
          <i class="fa-solid fa-folder-open"></i> My Portfolio
        </a>

        <a href="code.php">
          <i class="fa-solid fa-code"> </i> Coding Examples
        </a>

        <a href="scs.php">
          <i class="fa-solid fa-graduation-cap"></i> SCS Scheme
        </a>

        <a href="index.php#contact">
          <i class="fa-solid fa-mobile-screen"></i> &nbsp;Contact Me
        </a>

        <div class="social-media">
          <!-- <a href="#" id="fb-ico"><i class="fa-brands fa-facebook-f"></i></a> -->
          <a
            href="https://www.linkedin.com/in/andrejs-volskis-32751b160/"
            class="li-ico"
            target="_blank"
            ><i class="fa-brands fa-linkedin-in"></i
          ></a>
          <a
            href="https://www.instagram.com/art_of_andyw/"
            class="insta"
            target="_blank"
            ><i class="fa-brands fa-instagram"></i
          ></a>
          <a href="https://github.com/deanyosla/" target="_blank" class="github"
            ><i class="fa-brands fa-github"></i
          ></a>
        </div>
      </div>